
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;

public class WordFrequency {
    
public static HashMap<String, Integer> sortByValue(HashMap<String, Integer> hm) {
    
      // Create a list from elements of HashMap
      //In a LinkedList:
      //Each element points to the next. 
      //It is a data structure consisting of a collection of nodes which together represent a sequence.
      //that's it easy to judge what is next word is coming to be compared with the previous one.
      
      //In a HashMap:
      //Hashing is a technique of converting a large String to small String that represents the same String.
      //A shorter value helps in indexing and faster searches. 
      //HashSet also uses HashMap internally.
      // It stores the data in (Key, Value) pairs
      // so it provides faster searches while reading the objects
      
      java.util.List<Map.Entry<String, Integer> > list = new LinkedList<Map.Entry<String, Integer> >(hm.entrySet());
      
      // Sort the list for indexing purposes

      Collections.sort(list, new java.util.Comparator<Map.Entry<String, Integer> >() {

        public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {

          return (o2.getValue()).compareTo(o1.getValue());
        }

      });

      // put data from sorted list to hashmap
      
      //In a LinkedHashMap:
      //A LinkedHashMap is a combination of hash table and linked list. 
      //It has a predictable iteration order (a la linked list), yet the retrieval speed is that of a HashMap. 
      //The order of the iteration is determined by the insertion order, 
      //so you will get the key/values back in the order that they were added to this Map.
      
      HashMap<String, Integer> temp = new LinkedHashMap<String, Integer>();

      for (Map.Entry<String, Integer> aa : list) {

        temp.put(aa.getKey(), aa.getValue());

      }
      
      //return the sorted hashmap...
      return temp;

    }



    public static void main( String[] args ) throws FileNotFoundException  {

         //Songs used: 10,000 Hours by Dan, Sha & Justin...
        // open the file
        
        //In a Scanner:
        //the input of the primitive types like int, double, etc. and strings
        // it allows to read what is coming next in the collection of strings.
        
        Scanner console = new Scanner(System.in);
        String fileName = "song.txt";
        Scanner input = new Scanner(new File(fileName));

        // count occurrences

        HashMap<String, Integer> wordCounts = new HashMap<String, Integer>();
        
        //loop to read all the data from the file
        // saving the file in projectlevel directory to fetch data.
        while (input.hasNext()) {
            String next = input.next().toLowerCase();
            String clean = next;
            if (!wordCounts.containsKey(clean)) {
                wordCounts.put(clean, 1);
            } else {
                wordCounts.put(clean, wordCounts.get(clean) + 1);
            }
        }

        System.out.println("Total words = " + wordCounts.size());
        
        //Sending and Retriveing results from Class function named sortByValue()
        
        HashMap<String, Integer> sortedMapAsc = WordFrequency.sortByValue(wordCounts);
        // Report frequencies  
        for (String word : sortedMapAsc.keySet()) {

            int count = sortedMapAsc.get(word); 
            //Displays the results for sorted hashmap.
            System.out.println(count + ": " + word);
           
        }

    }
    
}
